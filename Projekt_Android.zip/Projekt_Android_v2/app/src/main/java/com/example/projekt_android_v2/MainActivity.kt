package com.example.projekt_android_v2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.content.Intent
import java.io.File
import java.nio.charset.Charset


class MainActivity : AppCompatActivity() {

    lateinit var btn_register : Button
    lateinit var btn_login : Button
    lateinit var et_user: EditText
    lateinit var et_password: EditText
    lateinit var file: File

    fun saveToFile(username: String, password: String): Boolean {
        if (file.exists()) {
            file.writeText(username + ";" + password, Charset.defaultCharset())
            //file.appendText()
            return true
        }
        else {
            file.createNewFile()
            if (file.exists()) {
                file.writeText(username + ";" + password, Charset.defaultCharset())
                //file.appendText()
                return true
            }
            else {
                Toast.makeText(
                    this@MainActivity,
                    "Błąd: brak pliku kont",
                    Toast.LENGTH_SHORT
                ).show()
                return false
            }
        }
    }

    fun readFromFile(): List<String> {
        if (file.exists()) return file.readLines()
        else return emptyList()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btn_register = findViewById(R.id.btn_register)
        btn_login = findViewById(R.id.btn_login)
        et_user = findViewById(R.id.et_register_user)
        et_password = findViewById(R.id.et_register_password)
        var path = this.filesDir
        var letDirectory = File(path, "LET")
        letDirectory.mkdirs()
        file = File(letDirectory, "users.txt")

        btn_login.setOnClickListener {
            var Logged = false
            when {
                TextUtils.isEmpty(et_user.text.toString().trim { it <= ' ' }) -> {
                    Toast.makeText(
                        this@MainActivity,
                        "Proszę podać adres email.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                TextUtils.isEmpty(et_password.text.toString().trim { it <= ' ' }) -> {
                    Toast.makeText(
                        this@MainActivity,
                        "Proszę wpisać hasło.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                else -> {
                    val username: String = et_user.text.toString()
                    val password: String = et_password.text.toString()
                    var list: List<String> = readFromFile()
                    if (list.isNotEmpty()) {
                        for (i in list) {
                            val Str: List<String> = i.split(";")
                            if(username == Str[0] && password == Str[1]) {
                                Logged = true
                                val intent = Intent(this@MainActivity, RemoteActivity::class.java)
                                startActivity(intent)
                                break
                            }
                        }
                        if (!Logged) {
                            Toast.makeText(
                                this@MainActivity,
                                "Niepoprawna nazwa użytkownika, bądź hasło",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        Toast.makeText(
                            this@MainActivity,
                            "Brak zarejestrowanych użytkowników",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }

        btn_register.setOnClickListener{
            when {
                TextUtils.isEmpty(et_user.text.toString().trim{it <= ' '}) -> {
                    Toast.makeText(
                        this@MainActivity,
                        "Proszę podać adres email.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                TextUtils.isEmpty(et_password.text.toString().trim{it <= ' '}) -> {
                    Toast.makeText(
                        this@MainActivity,
                        "Proszę wpisać hasło.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                else -> {
                    val username: String = et_user.text.toString()
                    val password: String = et_password.text.toString()
                    var list: List<String> = readFromFile()
                    if (list.isNotEmpty()) {
                        var registered = false
                        for (i in list) {
                            val Str: List<String> = i.split(";")
                            if (username == Str[0] && password == Str[1]) {
                                registered = true
                                Toast.makeText(
                                    this@MainActivity,
                                    "Użytkownik jest już zarejestrowany",
                                    Toast.LENGTH_SHORT
                                ).show()
                                break
                            }
                        }
                        
                        if (!registered) {
                            if(saveToFile(username, password)) {
                                Toast.makeText(
                                    this@MainActivity,
                                    "Zostałeś poprawnie zarejestrowany",
                                    Toast.LENGTH_SHORT
                                ).show()
                                val intent = Intent(this@MainActivity, RemoteActivity::class.java)
                                startActivity(intent)
                            }
                        }
                    }
                }
            }
        }
    }
}