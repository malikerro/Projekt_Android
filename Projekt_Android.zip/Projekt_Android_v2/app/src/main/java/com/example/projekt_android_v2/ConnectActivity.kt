package com.example.projekt_android_v2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.projekt_android_v2.databinding.ActivityConnectBinding


class ConnectActivity: AppCompatActivity(){

    private lateinit var binding: ActivityConnectBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConnectBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var logoutBtn: Button = findViewById(R.id.btn_logout)

        logoutBtn.setOnClickListener {
            startActivity(Intent(this@ConnectActivity, MainActivity::class.java))
            finish()
        }
    }
}
