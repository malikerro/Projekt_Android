package com.example.projekt_android_v2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import com.example.projekt_android_v2.databinding.ActivityControlBinding
import android.widget.Toast


class RemoteActivity : AppCompatActivity(){

    private lateinit var binding: ActivityControlBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityControlBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val txt1: String = ": zapalam światło "
        val txt2: String = ": gaszę światła"
        var room: String
        val colors = arrayOf<String>("czerwone", "zielone", "niebieskie")
        val rooms = arrayOf<String>("Kuchnia", "Sypialnia", "Salon", "Lazienka", "Garaż", "Przedpokój")

        binding.apply {
            btnKitchenRedLight.setOnClickListener{
                room = rooms[0]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[0], Toast.LENGTH_SHORT
                ).show()
            }
            btnKitchenGreenLight.setOnClickListener{
                room = rooms[0]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[1], Toast.LENGTH_SHORT
                ).show()
            }
            btnKitchenBlueLight.setOnClickListener{
                room = rooms[0]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[2], Toast.LENGTH_SHORT
                ).show()
            }
            btnKitchenLightsOff.setOnClickListener{
                room = rooms[0]
                Toast.makeText(
                    this@RemoteActivity,room + txt2, Toast.LENGTH_SHORT
                ).show()
            }

            /*----------------------------------------*/

            btnBedroom1RedLight.setOnClickListener{
                room = rooms[1]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[0], Toast.LENGTH_SHORT
                ).show()
            }
            btnBedroom1GreenLight.setOnClickListener{
                room = rooms[1]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[1], Toast.LENGTH_SHORT
                ).show()
            }
            btnBedroom1BlueLight.setOnClickListener{
                room = rooms[1]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[2], Toast.LENGTH_SHORT
                ).show()
            }
            btnBedroom1LightsOff.setOnClickListener{
                room = rooms[1]
                Toast.makeText(
                    this@RemoteActivity,room + txt2, Toast.LENGTH_SHORT
                ).show()
            }

            /*-----------------------------------------------*/

            btnLivingroomRedLight.setOnClickListener{
                room = rooms[2]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[0], Toast.LENGTH_SHORT
                ).show()
            }
            btnLivingroomGreenLight.setOnClickListener{
                room = rooms[2]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[1], Toast.LENGTH_SHORT
                ).show()
            }
            btnLivingroomBlueLight.setOnClickListener{
                room = rooms[2]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[2], Toast.LENGTH_SHORT
                ).show()
            }
            btnLivingroomLightsoffLight.setOnClickListener{
                room = rooms[2]
                Toast.makeText(
                    this@RemoteActivity,room + txt2, Toast.LENGTH_SHORT
                ).show()
            }

            /*-------------------------------------------------*/

            btnToiletRedLight.setOnClickListener{
                room = rooms[3]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[0], Toast.LENGTH_SHORT
                ).show()
            }
            btnToiletGreenLight.setOnClickListener{
                room = rooms[3]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[1], Toast.LENGTH_SHORT
                ).show()
            }
            btnToiletBlueLight.setOnClickListener{
                room = rooms[3]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[2], Toast.LENGTH_SHORT
                ).show()
            }
            btnToiletLightsOff.setOnClickListener{
                room = rooms[3]
                Toast.makeText(
                    this@RemoteActivity,room + txt2, Toast.LENGTH_SHORT
                ).show()
            }

            /*-------------------------------------------------*/

            btnGarageRedLight.setOnClickListener{
                room = rooms[4]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[0], Toast.LENGTH_SHORT
                ).show()
            }
            btnGarageGreenLight.setOnClickListener{
                room = rooms[4]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[1], Toast.LENGTH_SHORT
                ).show()
            }
            btnGarageBlueLight.setOnClickListener{
                room = rooms[4]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[2], Toast.LENGTH_SHORT
                ).show()
            }
            btnGarageLightsOff.setOnClickListener{
                room = rooms[4]
                Toast.makeText(
                    this@RemoteActivity,room + txt2, Toast.LENGTH_SHORT
                ).show()
            }

            /*-------------------------------------------------*/

            btnParkingControlOn.setOnClickListener{
                room = rooms[4]
                Toast.makeText(
                    this@RemoteActivity,room + ": włączam czujnik parkowania", Toast.LENGTH_SHORT
                ).show()
            }
            btnParkingControlOff.setOnClickListener{
                room = rooms[4]
                Toast.makeText(
                    this@RemoteActivity,room + ": wyłączam czujnik parkowania", Toast.LENGTH_SHORT
                ).show()
            }
            btnGarageGateControlUp.setOnClickListener{
                room = rooms[4]
                Toast.makeText(
                    this@RemoteActivity,room + ": podnoszę bramę", Toast.LENGTH_SHORT
                ).show()
            }
            btnGarageGateControlDown.setOnClickListener{
                room = rooms[4]
                Toast.makeText(
                    this@RemoteActivity,room + ": opuszczam bramę", Toast.LENGTH_SHORT
                ).show()
            }

            /*-------------------------------------------------*/

            btnHallRedLight.setOnClickListener{
                room = rooms[5]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[0], Toast.LENGTH_SHORT
                ).show()
            }
            btnHallGreenLight.setOnClickListener{
                room = rooms[5]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[1], Toast.LENGTH_SHORT
                ).show()
            }
            btnHallBlueLight.setOnClickListener{
                room = rooms[5]
                Toast.makeText(
                    this@RemoteActivity,room + txt1 + colors[2], Toast.LENGTH_SHORT
                ).show()
            }
            btnHallLightsOff.setOnClickListener{
                room = rooms[5]
                Toast.makeText(
                    this@RemoteActivity,room + txt2, Toast.LENGTH_SHORT
                ).show()
            }
        }
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.id_list){
            val intent = Intent(this@RemoteActivity, ConnectActivity::class.java)
            startActivity(intent)
        } else if(item.itemId == R.id.id_connect){
            Toast.makeText(
                this@RemoteActivity,"łączenie Bluetooth", Toast.LENGTH_SHORT
            ).show()
        }
        return super.onOptionsItemSelected(item)
    }
}